"""Local behavioral tests: tone fixtures establish timing/failure semantics, not speech quality."""
import importlib.util
import json
import math
import struct
import sys
import tempfile
import unittest
import wave
import io
from unittest.mock import patch
from pathlib import Path

SCRIPTS=Path(__file__).resolve().parents[1]/'scripts'
sys.path.insert(0,str(SCRIPTS))
import studio_speech
from voice import synthesize,compose
from qa import compare,inspect
from studio import build
from render import prepare,render,probe


class VoiceTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
        for i,seconds in enumerate([.4,.7]):
            with wave.open(str(self.root/f'{i}.wav'),'wb') as w:
                w.setnchannels(1);w.setsampwidth(2);w.setframerate(48000)
                w.writeframes(b''.join(struct.pack('<h',round(5000*math.sin(n*2*math.pi*300/48000)))for n in range(round(seconds*48000))))
        self.text=self.root/'text.txt';self.text.write_text('Exact test phrase.',encoding='utf-8')
        self.cfg=self.root/'config.json'

    def tearDown(self):self.tmp.cleanup()

    def config(self,command):
        cfg=dict(provider='synthetic-test',model='tone-fixture',revision='1',network='none',languages=['en'],voices=['fixture'],command=command)
        self.cfg.write_text(json.dumps(cfg),encoding='utf-8');return cfg

    def test_unsupported_language_never_invokes_provider(self):
        marker=self.root/'invoked'
        self.config([sys.executable,'-c',f"open({str(marker)!r},'w').write('bad')",'{input}','{output}'])
        with self.assertRaisesRegex(ValueError,'unsupported'):synthesize(self.cfg,self.text,self.root/'out.wav','ar','fixture')
        self.assertFalse(marker.exists())

    def test_provider_failure_has_no_fallback_or_partial_output(self):
        self.config([sys.executable,'-c','raise SystemExit(9)','{input}','{output}'])
        with self.assertRaisesRegex(ValueError,'no fallback'):synthesize(self.cfg,self.text,self.root/'out.wav','en','fixture')
        self.assertFalse((self.root/'out.wav').exists())

    def test_explicit_provider_audio_and_identity_no_overwrite(self):
        self.config([sys.executable,'-c',f"import shutil,sys;shutil.copyfile({str(self.root/'0.wav')!r},sys.argv[2])",'{input}','{output}'])
        out=self.root/'out.wav';receipt=synthesize(self.cfg,self.text,out,'en','fixture')
        self.assertEqual(receipt['voice'],'fixture');self.assertEqual(receipt['language'],'en')
        self.assertEqual(out.read_bytes(),(self.root/'0.wav').read_bytes())
        with self.assertRaisesRegex(ValueError,'exists'):synthesize(self.cfg,self.text,out,'en','fixture')

    def test_phrase_boundaries_follow_audio_duration(self):
        spec=self.root/'phrases.json';spec.write_text(json.dumps({'phrases':[{'audio':'0.wav','text':'First phrase.'},{'audio':'1.wav','text':'Second phrase.'}]}),encoding='utf-8')
        result=compose(spec,self.root/'composed')
        self.assertAlmostEqual(result['captions'][1]['start'],.4,places=5)
        self.assertAlmostEqual(result['captions'][1]['end'],1.1,places=5)
        self.assertAlmostEqual(float(probe(self.root/'composed/narration.wav')['format']['duration']),1.1,places=4)

    def test_order_negations_numbers_and_duplicates_are_not_lost(self):
        for a,b in [('Do not send it.','Do send it.'),('Send two files.','Send three files.'),('Click save then close.','Click close then save.'),('Go go now.','Go now.')]:
            self.assertFalse(compare(a,b)['exactOrderedMatch'])
        self.assertTrue(compare('Save the file.','save the file!')['exactOrderedMatch'])

    def test_studio_client_uses_server_resolved_english_reference(self):
        reference_hash='f'*64
        status={'config':{'engine':'omnivoice','voice':'mine','profileReady':True,'languages':['en','ar'],'references':{},'accepted':{'ar':{'engine':'omnivoice','referenceSha256':reference_hash}}},'engines':{'omnivoice':{'langs':['en','ar']}},'mine':{'en':{'sha256':reference_hash}},'effectiveReferences':{'en':'en','ar':'en'},'plan':{'models':[{'id':'omnivoice','repo':'synthetic-test/voice','revision':'test'}]}}
        posts=[]
        def response(request,timeout):
            if isinstance(request,str):return io.BytesIO(json.dumps(status).encode())
            posts.append(json.loads(request.data));audio=io.BytesIO(b'synthetic-provider-response')
            audio.headers={'X-Voice':'omnivoice; cloned=True; lang=ar','X-Voice-Reference-SHA256':reference_hash,'X-Voice-Reference-Language':'en'}
            return audio
        def convert(args):Path(args[-1]).write_bytes((self.root/'0.wav').read_bytes())
        with patch.object(studio_speech.urllib.request,'urlopen',response),patch.object(studio_speech,'command',convert):
            receipt=studio_speech.generate(self.text,self.root/'accepted-ar.wav','ar')
        self.assertEqual(receipt['referenceLanguage'],'en');self.assertEqual(receipt['referenceSha256'],reference_hash)
        self.assertEqual(posts,[{'input':'Exact test phrase.','language':'ar','engine':'omnivoice','mine':True}])
        self.assertEqual((self.root/'accepted-ar.wav').read_bytes(),(self.root/'0.wav').read_bytes())
    def test_english_digits_compare_as_the_spoken_words(self):
        heard='We made over 2,000 commits; 71% landed in 3.5 weeks.'
        self.assertTrue(compare('We made over two thousand commits; seventy-one percent landed in three point five weeks.',heard,'en')['exactOrderedMatch'])
        self.assertFalse(compare('Send two files.','Send 3 files.','en')['exactOrderedMatch'])
        self.assertFalse(compare('Send two thousand files.','Send 2,000 files.')['exactOrderedMatch'],'Other languages keep digits literal')

    def test_landscape_export_gets_a_landscape_contact_sheet(self):
        from PIL import Image
        Image.new('RGB',(640,360),'#335566').save(self.root/'still.png')
        plan=dict(version=1,width=640,height=360,fps=30,voice=dict(provider='test',model='tone-fixture',revision='1',name='not-speech',language='en'),
                  scenes=[dict(kind='still',status='demonstration',title='Hold',visual='still.png',audio='1.wav',say='Synthetic tone.',captions=[dict(start=0,end=.7,text='Synthetic tone.')])])
        (self.root/'plan.json').write_text(json.dumps(plan),encoding='utf-8')
        render(self.root/'plan.json',self.root/'cut')
        inspect(self.root/'cut/walkthrough.mp4',self.root/'cut/evidence.json',self.root/'qa')
        with Image.open(self.root/'qa/contact-sheet.jpg') as sheet:self.assertGreater(sheet.width,sheet.height)

    def test_audition_escapes_content_and_keeps_audio(self):
        spec=self.root/'audition.json';spec.write_text(json.dumps({'takes':[dict(name='<unsafe>',provider='test',model='tone',revision='1',language='en',text='Synthetic tone, not speech.',audio='0.wav')]}),encoding='utf-8')
        out=self.root/'studio';build(spec,out)
        text=(out/'index.html').read_text(encoding='utf-8')
        self.assertIn('&lt;unsafe&gt;',text);self.assertNotIn('<unsafe>',text)
        self.assertEqual((out/'take-0.wav').read_bytes(),(self.root/'0.wav').read_bytes())


if __name__=='__main__':unittest.main()
